import { FormEvent, useEffect, useMemo, useRef, useState } from "react"
import Notifications from "./Notifications"
import Community from "./Community"
import { Icon } from "./Icon"

type Theme = "light" | "dark" | "system"

type View = "discover" | "player" | "community" | "publish" | "billing" | "profile"
type Modal = "login" | "settings" | "onboarding" | "ai" | "legal" | "comment" | null

const artists = [
  {
    id: "valentina-cruz",
    name: "Valentina Cruz",
    track: "Río de Fuego",
    genre: "R&B afrolatino",
    area: "San Antonio",
    match: 94,
    cover: "cover-valentina-cruz.svg",
    audio: "rio-de-fuego.wav",
    story:
      "Voces suaves, percusión del Pacífico y una narrativa íntima sobre crecer cerca del río y volver a la ciudad con identidad propia.",
    tags: ["Afro urbano", "Voz cálida", "Cali nocturna"],
  },
  {
    id: "maelo-solar",
    name: "Kmelo",
    track: "Barrio Norte",
    genre: "Hip hop alternativo",
    area: "La Flora",
    match: 88,
    cover: "cover-kmelo.svg",
    audio: "barrio-norte.wav",
    story:
      "Rap de observación urbana con beats cálidos y referencias a movilidad, universidad y vida de barrio.",
    tags: ["Rap local", "Lírica urbana", "Beat cálido"],
  },
  {
    id: "nina-santacruz",
    name: "Soledad",
    track: "Palmeras de Sal",
    genre: "Pop tropical",
    area: "El Peñón",
    match: 91,
    cover: "cover-soleada.svg",
    audio: "palmeras-de-sal.wav",
    story:
      "Pop luminoso con percusión latina, diseñado para cápsulas breves y fácil recordación.",
    tags: ["Pop local", "Hook rápido", "Lista de verano"],
  },
  {
    id: "duo-cables",
    name: "Andrés Mora",
    track: "Cables de Lluvia",
    genre: "Electrónica orgánica",
    area: "Granada",
    match: 82,
    cover: "cover-andres-mora.svg",
    audio: "cables-de-lluvia.wav",
    story:
      "Texturas electrónicas inspiradas en lluvia, tráfico y noches de estudio en el oeste de Cali.",
    tags: ["Electrónica", "Textura ambiental", "Noche"],
  },
  {
    id: "santa-loma",
    name: "Maracuyás",
    track: "Tierra Sonora",
    genre: "Fusión pacífico",
    area: "Siloé",
    match: 90,
    cover: "cover-maracuyas.svg",
    audio: "tierra-sonora.wav",
    story:
      "Marimba, bajo moderno y relato sobre memoria familiar entre ladera, mercado y escena independiente.",
    tags: ["Fusión", "Pacífico", "Raíz"],
  },
  {
    id: "lucia-puerto",
    name: "Los Pleneros",
    track: "Amanecer del Puerto",
    genre: "Soul latino",
    area: "Alameda",
    match: 86,
    cover: "cover-pleneros.svg",
    audio: "amanecer-del-puerto.wav",
    story:
      "Soul con guitarras limpias y narrativa de trayectos cotidianos, mercado y madrugadas creativas.",
    tags: ["Soul", "Guitarra limpia", "Madrugada"],
  },
  {
    id: "aurora-ladera",
    name: "Naya del Valle",
    track: "Aurora de Ladera",
    genre: "Neo soul caleño",
    area: "Terrón Colorado",
    match: 89,
    cover: "cover-aurora-ladera.svg",
    audio: "aurora-de-ladera.wav",
    story:
      "Voces suaves, bajo redondo y una historia sobre mirar la ciudad desde la ladera antes de empezar el día.",
    tags: ["Neo soul", "Ladera", "Voz íntima"],
  },
  {
    id: "medianoche-alameda",
    name: "Cromo Pacífico",
    track: "Medianoche Alameda",
    genre: "House latino",
    area: "Alameda",
    match: 84,
    cover: "cover-medianoche-alameda.svg",
    audio: "medianoche-alameda.wav",
    story:
      "Percusión filtrada, sintetizadores nocturnos y una lectura sonora del mercado y sus luces.",
    tags: ["House", "Nocturno", "Percusión"],
  },
  {
    id: "brisa-oriente",
    name: "Lía Montoya",
    track: "Brisa del Oriente",
    genre: "Pop urbano",
    area: "Ciudad Córdoba",
    match: 87,
    cover: "cover-brisa-oriente.svg",
    audio: "brisa-del-oriente.wav",
    story:
      "Melodía pegajosa, percusión ligera y una cápsula sobre amistad, buses, colegio y tardes al oriente de Cali.",
    tags: ["Pop urbano", "Hook rápido", "Oriente"],
  },
]

const profiles = [
  {
    name: "Luna Martinez",
    role: "Exploradora musical",
    key: "user",
    avatar: "luna-catalina-martinez.svg",
  },
  {
    name: "Johan Guzman",
    role: "Oyente curador",
    key: "curator",
    avatar: "johan-stiven-guzman.svg",
  },
  {
    name: "Karold Mejia",
    role: "Artista local",
    key: "artist",
    avatar: "karold-lizeth-mejia-orozco.svg",
  },
  {
    name: "Renzo Mosquera",
    role: "Empresa / talento",
    key: "company",
    avatar: "renzo-mosquera-daza.svg",
  },
]

const plans = [
  {
    name: "KORΛ Base",
    price: "Incluido",
    copy: "Cápsulas, guardados y comunidad pública.",
    audience: "Exploradores",
  },
  {
    name: "KORΛ Premium Ligero",
    price: "$12.900",
    copy: "Descubrimiento ampliado, listas y acceso anticipado.",
    audience: "Usuarios frecuentes",
  },
  {
    name: "KORΛ Artista",
    price: "$24.900",
    copy: "Publicación, recepción y estado de licencia.",
    audience: "Artistas",
  },
  {
    name: "KORΛ Empresas CM",
    price: "$69.900",
    copy: "Radar, escenas y métricas agregadas autorizadas.",
    audience: "Empresas y talento",
  },
]

const nav: { id: View; label: string; icon: string }[] = [
  { id: "discover", label: "Descubrir", icon: "home" },
  { id: "player", label: "Reproductor", icon: "play" },
  { id: "community", label: "Comunidad", icon: "community" },
  { id: "publish", label: "Publicar", icon: "plus" },
  { id: "billing", label: "Planes", icon: "plans" },
  { id: "profile", label: "Perfil", icon: "user" },
]

const cover = (file: string) => `/kora/img/${file}`
const audio = (file: string) => `/kora/audio/${file}`

export default function App() {
  const [theme, setTheme] = useState<Theme>(() => {
    try {
      const t = localStorage.getItem("kora-theme")
      return t === "light" || t === "dark" ? t : "system"
    } catch {
      return "system"
    }
  })
  const [collapsed, setCollapsed] = useState(false)
  useEffect(() => {
    const media = matchMedia("(prefers-color-scheme: dark)")
    const apply = () => {
      document.documentElement.dataset.theme =
        theme === "system" ? (media.matches ? "dark" : "light") : theme
    }
    apply()
    try {
      localStorage.setItem("kora-theme", theme)
    } catch {}
    media.addEventListener("change", apply)
    return () => media.removeEventListener("change", apply)
  }, [theme])
  const [view, setView] = useState<View>(() => new URLSearchParams(location.search).has("comunidad") ? "community" : "discover")
  const [current, setCurrent] = useState(0)
  const [saved, setSaved] = useState<string[]>(() =>
    JSON.parse(localStorage.getItem("kora-saved") || "[]"),
  )
  const [liked, setLiked] = useState<string[]>([])
  const [playing, setPlaying] = useState(false)
  const [expanded, setExpanded] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState(1)
  const resumePlayback = useRef(false)
  const [modal, setModal] = useState<Modal>("onboarding")
  const [profile, setProfile] = useState(profiles[0])
  const [toast, setToast] = useState("")
  const player = useRef<HTMLAudioElement>(null)
  const artist = artists[current]
  const visibleNav = nav.filter(
    (n) => n.id !== "publish" || profile.key === "artist",
  )

  useEffect(() => {
    localStorage.setItem("kora-saved", JSON.stringify(saved))
  }, [saved])
  useEffect(() => {
    setElapsed(0)
    setDuration(0)
    player.current?.load()
  }, [current])
  useEffect(() => {
    if (!toast) return
    const t = setTimeout(() => setToast(""), 2400)
    return () => clearTimeout(t)
  }, [toast])

  const togglePlay = async () => {
    const element = player.current
    if (!element) return
    if (!element.paused) {
      element.pause()
      return
    }
    try {
      await element.play()
    } catch {
      setToast("No se pudo reproducir el audio. Vuelve a intentarlo.")
    }
  }
  const selectTrack = (index: number, autoplay = playing) => {
    if (index === current) {
      if (autoplay && player.current?.paused) void togglePlay()
      return
    }
    resumePlayback.current = autoplay
    setCurrent((index + artists.length) % artists.length)
  }
  const seek = (value: number) => {
    if (player.current && duration > 0) {
      player.current.currentTime = value
      setElapsed(value)
    }
  }
  const changeVolume = (value: number) => {
    if (player.current) player.current.volume = value
    setVolume(value)
  }
  const shareCurrent = async () => {
    const payload = {
      title: `${artist.track} · ${artist.name}`,
      url: location.href,
    }
    if (navigator.share) {
      try {
        await navigator.share(payload)
        return
      } catch (error) {
        // Cancelling the native sheet is not a failure and needs no fallback.
        if (error instanceof DOMException && error.name === "AbortError") return
      }
    }
    try {
      await navigator.clipboard.writeText(payload.url)
      setToast("Enlace copiado al portapapeles")
    } catch {
      setToast(
        "No se pudo compartir ni copiar. Copia el enlace desde la barra de direcciones.",
      )
    }
  }
  const toggleSave = (id = artist.id) => {
    setSaved((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]))
    setToast(
      saved.includes(id)
        ? "Quitado de tu memoria musical"
        : "Guardado en tu memoria musical",
    )
  }
  const goArtist = (index: number) => {
    selectTrack(index)
    setView("player")
  }
  const playerProps = {
    artist,
    playing,
    elapsed,
    duration,
    volume,
    saved: saved.includes(artist.id),
    liked: liked.includes(artist.id),
    onPlay: togglePlay,
    onSave: () => toggleSave(),
    onLike: () =>
      setLiked((s) =>
        s.includes(artist.id)
          ? s.filter((x) => x !== artist.id)
          : [...s, artist.id],
      ),
    onPrev: () => selectTrack(current - 1),
    onNext: () => selectTrack(current + 1),
    onShare: shareCurrent,
    onSeek: seek,
    onVolume: changeVolume,
    onFullscreen: () => setExpanded(true),
    onSelect: (index: number) => selectTrack(index),
  }

  return (
    <div className={`app ${collapsed ? "is-collapsed" : ""}`}>
      <aside className="sidebar">
        <button
          className="brand"
          onClick={() => setView("discover")}
          aria-label="KORA inicio"
        >
          <span>KORΛ</span>
          <small>Música emergente</small>
        </button>
        <button
          className="collapse-toggle"
          aria-label={collapsed ? "Expandir navegación" : "Contraer navegación"}
          onClick={() => setCollapsed(!collapsed)}
        >
          <Icon name="sidebar" />
        </button>
        <nav className="nav" aria-label="Navegación principal">
          {visibleNav.map((item) => (
            <button
              key={item.id}
              className={view === item.id ? "active" : ""}
              title={item.label}
              aria-label={item.label}
              aria-current={view === item.id ? "page" : undefined}
              onClick={() => setView(item.id)}
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="side-tools">
          <button onClick={() => setModal("ai")}>
            <Icon name="sparkles" /> <span>KORΛ IA</span>
          </button>

          <button onClick={() => setModal("settings")}>
            <Icon name="settings" /> <span>Ajustes</span>
          </button>
        </div>
        <button className="account" onClick={() => setModal("login")}>
          <img src={cover(profile.avatar)} alt="" />
          <span>
            <strong>{profile.name}</strong>
            <small>{profile.role}</small>
          </span>
          <Icon name="down" />
        </button>
      </aside>

      <main>
        <header>
          <div>
            <p className="eyebrow">
              KORΛ / {nav.find((n) => n.id === view)?.label}
            </p>
            <h1>{heading(view, profile.key)}</h1>
          </div>
          <div className="header-actions">
            <button
              className="icon-btn"
              onClick={() => setModal("settings")}
              aria-label="Ajustes y apariencia"
            >
              <Icon name="settings" />
            </button>
            <Notifications onOpen={goArtist} />
            <button className="avatar-btn" onClick={() => setModal("login")}>
              <img src={cover(profile.avatar)} alt={profile.name} />
            </button>
          </div>
        </header>

        {view === "discover" && (
          <Discover
            saved={saved}
            onSave={toggleSave}
            onOpen={goArtist}
            onPlay={(i) => {
              selectTrack(i, true)
              setView("player")
            }}
          />
        )}
        {view === "player" && <Player {...playerProps} />}
        {view === "community" && (
          <Community artists={artists} saved={saved} liked={liked} onSave={toggleSave} onLike={(id)=>setLiked(items=>items.includes(id)?items.filter(item=>item!==id):[...items,id])} onOpen={goArtist} />
        )}
        {view === "publish" && (
          <Publish
            onDone={() => setToast("Cápsula guardada como borrador local")}
          />
        )}
        {view === "billing" && (
          <Billing
            onDone={() =>
              setToast("Solicitud preparada. No se realizó ningún cobro.")
            }
          />
        )}
        {view === "profile" && (
          <Profile
            profile={profile}
            saved={saved}
            liked={liked}
            current={artist}
            onOpen={(id: string) =>
              goArtist(artists.findIndex((a) => a.id === id))
            }
            onLegal={() => setModal("legal")}
            onAccount={() => setModal("login")}
          />
        )}
      </main>

      <nav className="mobile-nav">
        {visibleNav.map((item) => (
          <button
            key={item.id}
            className={view === item.id ? "active" : ""}
            title={item.label}
            aria-label={item.label}
            aria-current={view === item.id ? "page" : undefined}
            onClick={() => setView(item.id)}
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="mini-player">
        <button
          className="mini-expand"
          onClick={() => setExpanded(true)}
          aria-label="Ampliar reproductor"
        >
          <img src={cover(artist.cover)} alt="" />
          <span className="mini-title">
            <strong>{artist.track}</strong>
            <span>{artist.name}</span>
          </span>
        </button>
        <button
          className="play-small"
          aria-label={playing ? "Pausar" : "Reproducir"}
          onClick={togglePlay}
        >
          <Icon name={playing ? "pause" : "play"} />
        </button>
      </div>
      <audio
        ref={player}
        src={audio(artist.audio)}
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={() => setPlaying(false)}
        onError={() => {
          setPlaying(false)
          setToast("El audio no está disponible. Intenta otra cápsula.")
        }}
        onTimeUpdate={(e) => setElapsed(e.currentTarget.currentTime)}
        onLoadedMetadata={(e) => {
          setDuration(
            Number.isFinite(e.currentTarget.duration)
              ? e.currentTarget.duration
              : 0,
          )
          if (resumePlayback.current) {
            resumePlayback.current = false
            void togglePlay()
          }
        }}
      />
      {expanded && (
        <ExpandedPlayer close={() => setExpanded(false)}>
          <Player {...playerProps} expanded />
        </ExpandedPlayer>
      )}
      {modal && (
        <ModalView
          type={modal}
          close={() => setModal(null)}
          profile={profile}
          setProfile={(p: typeof profiles[number]) => {
            setProfile(p)
            setModal(null)
            setToast(`Sesión cambiada a ${p.role}`)
          }}
          onLegal={() => setModal("legal")}
          theme={theme}
          setTheme={setTheme}
        />
      )}
      {toast && (
        <div className="toast" role="status">
          {toast}
        </div>
      )}
    </div>
  )
}

function heading(view: View, role: string) {
  if (view === "discover") return "Tu próxima canción favorita vive cerca"
  if (view === "player") return "Ahora suena en Cali"
  if (view === "community") return "La escena se construye en comunidad"
  if (view === "publish")
    return role === "artist"
      ? "Publica una nueva cápsula"
      : "Espacio del artista"
  if (view === "billing") return "Elige cómo vivir KORΛ"
  return "Tu espacio en KORΛ"
}

function Discover({
  saved,
  onSave,
  onOpen,
  onPlay,
}: {
  saved: string[]
  onSave: (id: string) => void
  onOpen: (i: number) => void
  onPlay: (i: number) => void
}) {
  const [genre, setGenre] = useState("Todos")
  const [query, setQuery] = useState("")
  const filtered = artists.filter(
    (a) =>
      (genre === "Todos" || a.genre === genre) &&
      `${a.name} ${a.track} ${a.area}`
        .toLowerCase()
        .includes(query.toLowerCase()),
  )
  const card = (a: typeof artists[number]) => (
    <article className="artist-card" key={a.id}>
      <button
        className="cover"
        onClick={() => onOpen(artists.indexOf(a))}
        aria-label={`Abrir ${a.track}`}
      >
        <img src={cover(a.cover)} alt={`Portada de ${a.track}`} />
        <span className="card-play">
          <Icon name="play" />
        </span>
      </button>
      <div className="card-meta">
        <button onClick={() => onOpen(artists.indexOf(a))}>
          <strong>{a.track}</strong>
          <span>
            {a.name} · {a.genre}
          </span>
        </button>
        <button
          aria-label={
            saved.includes(a.id) ? `Quitar ${a.track}` : `Guardar ${a.track}`
          }
          aria-pressed={saved.includes(a.id)}
          onClick={() => onSave(a.id)}
        >
          <Icon name={saved.includes(a.id) ? "check" : "plus"} />
        </button>
      </div>
    </article>
  )
  return (
    <div className="content discover-page">
      <div className="discovery-toolbar">
        <label>
          Buscar en la escena
          <input
            type="search"
            placeholder="Artista, canción o barrio"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </label>
        <span>{artists.length} cápsulas · Cali</span>
      </div>
      {!query && genre === "Todos" && (
        <section className="editorial-spotlight">
          <div>
            <p className="eyebrow">En foco · San Antonio</p>
            <h2>
              Una ciudad.
              <br />
              Muchas formas de sonar.
            </h2>
            <p>{artists[0].story}</p>
            <button className="primary" onClick={() => onPlay(0)}>
              <Icon name="play" />
              Escuchar Río de Fuego
            </button>
          </div>
          <button
            className="spotlight-cover"
            aria-label="Abrir Río de Fuego"
            onClick={() => onOpen(0)}
          >
            <img
              src={cover(artists[0].cover)}
              alt="Río de Fuego — Valentina Cruz"
            />
          </button>
        </section>
      )}
      <SectionTitle kicker="Explora tu escena" title="Encuentra tu sonido" />
      <div className="genre-strip" role="group" aria-label="Filtrar por género">
        {["Todos", ...new Set(artists.map((a) => a.genre))].map((g) => (
          <button
            key={g}
            aria-pressed={genre === g}
            onClick={() => setGenre(g)}
          >
            {g}
          </button>
        ))}
      </div>
      <SectionTitle
        kicker="Catálogo KORΛ"
        title={genre === "Todos" ? "Cápsulas para descubrir" : genre}
      />
      {filtered.length ? (
        <Carousel label="Cápsulas para descubrir">
          {filtered.map(card)}
        </Carousel>
      ) : (
        <div className="empty">
          <h3>No encontramos cápsulas</h3>
          <p>Prueba otro artista, barrio o género.</p>
          <button
            className="soft"
            onClick={() => {
              setQuery("")
              setGenre("Todos")
            }}
          >
            Restablecer búsqueda
          </button>
        </div>
      )}
      {!query && genre === "Todos" && (
        <>
          <SectionTitle
            kicker="Voces de la ciudad"
            title="Conoce a los artistas"
          />
          <Carousel label="Artistas de Cali">
            {artists.map((a, i) => (
              <button
                className="artist-portrait"
                key={a.id}
                onClick={() => onOpen(i)}
              >
                <img src={cover(a.cover)} alt="" />
                <strong>{a.name}</strong>
                <span>{a.area}</span>
              </button>
            ))}
          </Carousel>
          <SectionTitle kicker="Rutas locales" title="De barrio en barrio" />
          <Carousel label="Colecciones por barrio">
            {[...new Set(artists.map((a) => a.area))].map((area) => (
              <button
                className="area-card"
                key={area}
                onClick={() => setQuery(area)}
              >
                <img
                  src={cover(artists.find((a) => a.area === area)!.cover)}
                  alt=""
                />
                <span>
                  <strong>{area}</strong>
                  <small>
                    {artists.filter((a) => a.area === area).length} cápsula(s)
                  </small>
                </span>
                <Icon name="chevron" />
              </button>
            ))}
          </Carousel>
        </>
      )}
    </div>
  )
}

function Carousel({
  label,
  children,
}: {
  label: string
  children: React.ReactNode
}) {
  const rail = useRef<HTMLDivElement>(null)
  return (
    <section className="carousel" aria-label={label}>
      <div className="carousel-arrows">
        <button
          aria-label={`Anterior: ${label}`}
          onClick={() =>
            rail.current?.scrollBy({
              left: -rail.current.clientWidth * 0.8,
              behavior: matchMedia("(prefers-reduced-motion: reduce)").matches
                ? "auto"
                : "smooth",
            })
          }
        >
          <Icon name="previous" />
        </button>
        <button
          aria-label={`Siguiente: ${label}`}
          onClick={() =>
            rail.current?.scrollBy({
              left: rail.current.clientWidth * 0.8,
              behavior: matchMedia("(prefers-reduced-motion: reduce)").matches
                ? "auto"
                : "smooth",
            })
          }
        >
          <Icon name="next" />
        </button>
      </div>
      <div className="carousel-rail" ref={rail} tabIndex={0}>
        {children}
      </div>
    </section>
  )
}

function SectionTitle({
  kicker,
  title,
  action,
}: {
  kicker: string
  title: string
  action?: string
}) {
  return (
    <div className="section-title">
      <div>
        <p className="eyebrow">{kicker}</p>
        <h2>{title}</h2>
      </div>
      {action && (
        <button>
          {action} <Icon name="chevron" />
        </button>
      )}
    </div>
  )
}

function formatTime(value: number) {
  const n = Number.isFinite(value) ? Math.max(0, Math.floor(value)) : 0
  return `${Math.floor(n / 60)}:${String(n % 60).padStart(2, "0")}`
}
function Player({
  artist,
  playing,
  saved,
  liked,
  onPlay,
  onSave,
  onLike,
  onPrev,
  onNext,
  onShare,
  onFullscreen,
  elapsed,
  duration,
  volume,
  onSeek,
  onVolume,
  onSelect,
  expanded = false,
}: any) {
  return (
    <div
      className={`content player-page ${expanded ? "expanded-content" : ""}`}
    >
      <section className="player-stage">
        <div className="player-art">
          <div className="glow" />
          <img src={cover(artist.cover)} alt={`Portada de ${artist.track}`} />
        </div>
        <div className="player-copy">
          <p className="eyebrow">{artist.area} · Cali</p>
          <h2>{artist.track}</h2>
          <h3>{artist.name}</h3>
          <p className="story">{artist.story}</p>
          <div className="tags">
            {artist.tags.map((tag: string) => (
              <span key={tag}>{tag}</span>
            ))}
          </div>
          <div className="real-progress">
            <input
              type="range"
              aria-label="Posición de reproducción"
              min="0"
              max={duration || 0}
              step="0.1"
              value={Math.min(elapsed, duration || 0)}
              disabled={!duration}
              onChange={(e) => onSeek(Number(e.target.value))}
            />
            <div>
              <time>{formatTime(elapsed)}</time>
              <time>{formatTime(duration)}</time>
            </div>
          </div>
          <div className="transport">
            <button aria-label="Canción anterior" onClick={onPrev}>
              <Icon name="previous" />
            </button>
            <button
              className="main-play"
              aria-label={playing ? "Pausar" : "Reproducir"}
              onClick={onPlay}
            >
              <Icon name={playing ? "pause" : "play"} />
            </button>
            <button aria-label="Canción siguiente" onClick={onNext}>
              <Icon name="next" />
            </button>
          </div>
          <label className="volume-control">
            Volumen
            <input
              type="range"
              aria-label="Volumen"
              min="0"
              max="1"
              step="0.01"
              value={volume}
              onChange={(e) => onVolume(Number(e.target.value))}
            />
          </label>
          <div className="player-actions">
            <button
              aria-pressed={liked}
              className={liked ? "active" : ""}
              onClick={onLike}
            >
              <Icon name="heart" />
              <span>Me gusta</span>
            </button>
            <button
              aria-pressed={saved}
              className={saved ? "active" : ""}
              onClick={onSave}
            >
              <Icon name={saved ? "check" : "plus"} />
              <span>{saved ? "Guardado" : "Guardar"}</span>
            </button>
            <button onClick={onShare}>
              <Icon name="share" />
              <span>Compartir</span>
            </button>
            {!expanded && (
              <button onClick={onFullscreen}>
                <Icon name="expand" />
                <span>Ampliar</span>
              </button>
            )}
          </div>
        </div>
      </section>
      {!expanded && (
        <>
          <SectionTitle kicker="A continuación" title="Continúa el viaje" />
          <div className="playable-queue">
            {artists
              .filter((a) => a.id !== artist.id)
              .map((a) => (
                <button key={a.id} onClick={() => onSelect(artists.indexOf(a))}>
                  <img src={cover(a.cover)} alt="" />
                  <span>
                    <strong>{a.track}</strong>
                    <small>
                      {a.name} · {a.genre}
                    </small>
                  </span>
                  <Icon name="play" />
                </button>
              ))}
          </div>
        </>
      )}
    </div>
  )
}

function ExpandedPlayer({
  close,
  children,
}: {
  close: () => void
  children: React.ReactNode
}) {
  const panel = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const previous = document.activeElement as HTMLElement
    const overflow = document.body.style.overflow
    document.body.style.overflow = "hidden"
    panel.current?.querySelector<HTMLButtonElement>("button")?.focus()
    const handle = (e: KeyboardEvent) => {
      if (e.key === "Escape") close()
      if (e.key === "Tab") {
        const nodes = panel.current?.querySelectorAll<HTMLElement>(
          "button,input:not(:disabled)",
        )
        if (!nodes?.length) return
        const first = nodes[0],
          last = nodes[nodes.length - 1]
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault()
          last.focus()
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault()
          first.focus()
        }
      }
    }
    document.addEventListener("keydown", handle)
    return () => {
      document.body.style.overflow = overflow
      document.removeEventListener("keydown", handle)
      previous?.focus()
    }
  }, [])
  return (
    <div className="expanded-backdrop" onClick={close}>
      <div
        className="expanded-player"
        role="dialog"
        aria-modal="true"
        aria-label="Reproductor ampliado"
        ref={panel}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="expanded-heading">
          <button
            className="icon-btn"
            onClick={close}
            aria-label="Contraer reproductor"
          >
            <Icon name="down" />
          </button>
          <span>AHORA SUENA · KORΛ</span>
        </div>
        {children}
      </div>
    </div>
  )
}

function Publish({ onDone }: { onDone: () => void }) {
  const submit = (e: FormEvent) => {
    e.preventDefault()
    onDone()
  }
  return (
    <div className="content publish-layout">
      <form className="form-card" onSubmit={submit}>
        <p className="eyebrow">Espacio del artista</p>
        <h2>Nueva cápsula</h2>
        <p>Presenta una canción con el contexto que la hace única.</p>
        <div className="upload">
          <span>
            <Icon name="music" />
          </span>
          <strong>Sube tu audio</strong>
          <small>WAV o MP3 · Máximo 20 MB</small>
          <input type="file" accept="audio/*" />
        </div>
        <div className="two">
          <label>
            Título de la canción
            <input required placeholder="Ej. Luces del Sur" />
          </label>
          <label>
            Nombre artístico
            <input required defaultValue="Karold Mejia" />
          </label>
        </div>
        <label>
          Historia de la cápsula
          <textarea
            required
            placeholder="Cuenta el origen, el barrio y la intención de esta canción…"
          />
        </label>
        <div className="two">
          <label>
            Género
            <select>
              <option>R&B / Soul</option>
              <option>Rap / Hip hop</option>
              <option>Electrónica</option>
              <option>Fusión pacífico</option>
            </select>
          </label>
          <label>
            Barrio o escena
            <input placeholder="Ej. San Antonio" />
          </label>
        </div>
        <label className="check">
          <input type="checkbox" required /> Confirmo que tengo derechos para
          publicar esta cápsula y autorizo su reproducción dentro de KORΛ.
        </label>
        <button className="primary full">Guardar borrador</button>
      </form>
      <aside className="publish-side">
        <div className="preview-card">
          <p className="eyebrow">Vista previa</p>
          <div className="preview-art">Tu portada</div>
          <h3>Una historia antes del play</h3>
          <p>
            Las cápsulas con contexto claro generan mejores señales de escucha y
            guardado.
          </p>
        </div>
        <div className="checklist">
          <strong>Antes de publicar</strong>
          {[
            "Audio limpio y nivelado",
            "Portada con autorización",
            "Historia breve y concreta",
            "Licencia musical confirmada",
          ].map((x, i) => (
            <p key={x}>
              <span>
                <Icon name={i < 2 ? "check" : "user"} />
              </span>
              {x}
            </p>
          ))}
        </div>
      </aside>
    </div>
  )
}

function Billing({ onDone }: { onDone: () => void }) {
  const [selected, setSelected] = useState(1)
  return (
    <div className="content">
      <div className="plan-grid">
        {plans.map((p, i) => (
          <button
            key={p.name}
            onClick={() => setSelected(i)}
            className={selected === i ? "selected" : ""}
          >
            <span>{p.audience}</span>
            <h3>{p.name}</h3>
            <strong>
              {p.price}
              {i > 0 && <small> / mes</small>}
            </strong>
            <p>{p.copy}</p>
            <b>{selected === i ? "Seleccionado" : "Elegir plan"}</b>
          </button>
        ))}
      </div>
      <section className="checkout">
        <div>
          <p className="eyebrow">Solicitud de acceso</p>
          <h2>{plans[selected].name}</h2>
          <p>
            KORΛ prepara una solicitud por WhatsApp. Esta versión no procesa
            cobros automáticos.
          </p>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault()
            onDone()
          }}
        >
          <input required placeholder="Nombre completo" />
          <input required type="email" placeholder="Correo" />
          <select>
            <option>WhatsApp</option>
            <option>Transferencia</option>
          </select>
          <label className="check">
            <input type="checkbox" required /> Autorizo el tratamiento de mis
            datos para esta solicitud.
          </label>
          <button className="primary">Continuar con la solicitud</button>
        </form>
      </section>
    </div>
  )
}

function Profile({
  profile,
  saved,
  liked,
  current,
  onOpen,
  onLegal,
  onAccount,
}: any) {
  const savedArtists = artists.filter((a) => saved.includes(a.id))
  const genres = [...new Set(savedArtists.map((a) => a.genre))]
  return (
    <div className="content profile-page">
      <section className="profile-hero">
        <img src={cover(profile.avatar)} alt={`Avatar de ${profile.name}`} />
        <div>
          <p className="eyebrow">Perfil · {profile.role}</p>
          <h2>{profile.name}</h2>
          <p>Cali · Comunidad KORΛ</p>
          <div className="profile-summary">
            <span>{savedArtists.length} hallazgos guardados</span>
            <span>{liked.length} me gusta en esta sesión</span>
          </div>
        </div>
      </section>
      <div className="profile-actions">
        <button className="glass" onClick={onAccount}>
          <Icon name="user" />
          Cambiar perfil
        </button>
        <button className="soft" onClick={onLegal}>
          Privacidad y permisos
        </button>
      </div>
      <SectionTitle
        kicker="Tu biblioteca · En este dispositivo"
        title="Tus hallazgos"
      />
      {savedArtists.length ? (
        <Carousel label="Hallazgos guardados">
          {savedArtists.map((a) => (
            <button
              className="library-card"
              key={a.id}
              onClick={() => onOpen(a.id)}
            >
              <img src={cover(a.cover)} alt={`Portada de ${a.track}`} />
              <strong>{a.track}</strong>
              <span>{a.name}</span>
            </button>
          ))}
        </Carousel>
      ) : (
        <div className="empty">
          <Icon name="music" />
          <h3>Tu próximo hallazgo te espera</h3>
          <p>Guarda una cápsula en Descubrir para verla aquí.</p>
        </div>
      )}
      <div className="profile-details">
        <section>
          <p className="eyebrow">Tu selección</p>
          <h3>Los sonidos que guardas</h3>
          {genres.length ? (
            <div className="tags">
              {genres.map((g) => (
                <span key={g}>{g}</span>
              ))}
            </div>
          ) : (
            <p>Los géneros aparecerán cuando guardes canciones.</p>
          )}
        </section>
        <section>
          <p className="eyebrow">Reproductor actual</p>
          <h3>Tu sesión de escucha</h3>
          <button className="session-track" onClick={() => onOpen(current.id)}>
            <img src={cover(current.cover)} alt="" />
            <span>
              <strong>{current.track}</strong>
              <small>{current.name}</small>
            </span>
            <Icon name="play" />
          </button>
          <p>Solo mostramos actividad disponible en esta sesión.</p>
        </section>
      </div>
    </div>
  )
}

function ModalView({
  type,
  close,
  profile,
  setProfile,
  onLegal,
  theme,
  setTheme,
}: any) {
  const dialogRef = useRef<HTMLElement>(null)
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null
    const original = document.body.style.overflow
    document.body.style.overflow = "hidden"
    dialogRef.current?.querySelector<HTMLButtonElement>("button")?.focus()
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") close()
      if (event.key === "Tab") {
        const controls = dialogRef.current?.querySelectorAll<HTMLElement>(
          'button,input,textarea,select,[tabindex="0"]',
        )
        if (!controls?.length) return
        const first = controls[0],
          last = controls[controls.length - 1]
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault()
          last.focus()
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault()
          first.focus()
        }
      }
    }
    document.addEventListener("keydown", keydown)
    return () => {
      document.body.style.overflow = original
      document.removeEventListener("keydown", keydown)
      previous?.focus()
    }
  }, [])

  const content = useMemo(() => {
    if (type === "login")
      return (
        <>
          <p className="eyebrow">Perfiles de demostración</p>
          <h2>¿Cómo quieres vivir KORΛ?</h2>
          <p>Cada rol adapta acciones y herramientas a su propósito real.</p>
          <div className="profile-options">
            {profiles.map((p) => (
              <button
                className={profile.key === p.key ? "active" : ""}
                key={p.key}
                onClick={() => setProfile(p)}
              >
                <img src={cover(p.avatar)} alt="" />
                <span>
                  <strong>{p.name}</strong>
                  <small>{p.role}</small>
                </span>
                <b>
                  <Icon name="chevron" />
                </b>
              </button>
            ))}
          </div>
        </>
      )

    if (type === "settings")
      return (
        <>
          <p className="eyebrow">Preferencias</p>
          <h2>Ajustes</h2>
          <div className="appearance">
            <h3>Apariencia</h3>
            <div
              className="theme-picker"
              role="group"
              aria-label="Tema de la aplicación"
            >
              {(["light", "dark", "system"] as Theme[]).map((t) => (
                <button
                  key={t}
                  aria-pressed={theme === t}
                  onClick={() => setTheme(t)}
                >
                  <Icon
                    name={
                      t === "light" ? "sun" : t === "dark" ? "moon" : "system"
                    }
                  />
                  <span>
                    {t === "light"
                      ? "Claro"
                      : t === "dark"
                        ? "Oscuro"
                        : "Sistema"}
                  </span>
                </button>
              ))}
            </div>
            <p>La elección se guarda en este dispositivo.</p>
          </div>
          {[
            "Notificaciones de lanzamientos",
            "Modo privado",
            "Reproducción aleatoria",
            "Interfaz compacta",
            "Contraste reforzado",
          ].map((x, i) => (
            <label className="setting" key={x}>
              <span>
                <strong>{x}</strong>
                <small>
                  {i < 2
                    ? "Controla tu privacidad y avisos."
                    : "Personaliza tu experiencia de escucha."}
                </small>
              </span>
              <input type="checkbox" defaultChecked={i === 0 || i === 2} />
            </label>
          ))}
          <button className="legal-link" onClick={onLegal}>
            Ver privacidad y términos <Icon name="chevron" />
          </button>
        </>
      )
    if (type === "ai")
      return (
        <>
          <p className="eyebrow">Asistente contextual</p>
          <h2>KORΛ IA</h2>
          <p>
            Lee la cápsula activa y su contexto cultural para orientar tu
            descubrimiento.
          </p>
          <div className="ai-box">
            <span>
              <Icon name="sparkles" />
            </span>
            <p>
              <strong>
                Río de Fuego conecta San Antonio con la escena afro urbana.
              </strong>
              <small>
                Su voz entra rápido y el relato local la hace ideal para tu
                memoria musical.
              </small>
            </p>
          </div>
          <button className="soft full">Recomiéndame algo parecido</button>
          <button className="soft full">Resume el contexto cultural</button>
          <button className="soft full">Crear una ruta con este sonido</button>
        </>
      )
    if (type === "legal")
      return (
        <>
          <p className="eyebrow">Centro legal</p>
          <h2>Tu relación con KORΛ, clara</h2>
          <p>
            Consulta los documentos implementados en la plataforma original.
          </p>
          <div className="legal-docs">
            <button>
              <strong>Términos y condiciones</strong>
              <span>
                Uso responsable de la plataforma <Icon name="chevron" />
              </span>
            </button>
            <button>
              <strong>Datos personales</strong>
              <span>
                Tratamiento, permisos y derechos <Icon name="chevron" />
              </span>
            </button>
            <button>
              <strong>Licencia musical</strong>
              <span>
                Publicación y reproducción de cápsulas <Icon name="chevron" />
              </span>
            </button>
            <button>
              <strong>Pagos</strong>
              <span>
                Planes, solicitudes y condiciones <Icon name="chevron" />
              </span>
            </button>
          </div>
        </>
      )
    if (type === "comment")
      return (
        <>
          <p className="eyebrow">Comunidad</p>
          <h2>Añade contexto</h2>
          <p>
            Tu aporte será visible como señal comunitaria asociada a tu perfil.
          </p>
          <textarea
            className="modal-textarea"
            placeholder="¿Qué te conecta con esta canción?"
          />
          <div className="quick">
            <button>Contexto local</button>
            <button>Voto</button>
            <button>Recomendar</button>
          </div>
          <button className="primary full" onClick={close}>
            Publicar aporte
          </button>
        </>
      )
    return (
      <>
        <span className="welcome-mark">KORΛ</span>
        <p className="eyebrow">Bienvenida a la escena</p>
        <h2>Descubre la música que nace cerca</h2>
        <p>
          Escucha cápsulas, conoce la historia detrás de cada sonido y guarda
          los hallazgos que quieras recordar.
        </p>
        <div className="onboarding-steps">
          <div>
            <b>01</b>
            <span>
              <strong>Escucha</strong>
              <small>30 segundos para conectar.</small>
            </span>
          </div>
          <div>
            <b>02</b>
            <span>
              <strong>Descubre</strong>
              <small>Artistas, barrios y escenas.</small>
            </span>
          </div>
          <div>
            <b>03</b>
            <span>
              <strong>Participa</strong>
              <small>Tu señal mueve la comunidad.</small>
            </span>
          </div>
        </div>
        <button className="primary full" onClick={close}>
          Entrar a KORΛ
        </button>
      </>
    )
  }, [type, profile, close, onLegal, setProfile, theme, setTheme])
  return (
    <div className="modal-backdrop" onMouseDown={close}>
      <section
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-label="Panel de KORA"
        className="modal"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <button
          className="modal-close"
          aria-label="Cerrar panel"
          onClick={close}
        >
          <Icon name="close" />
        </button>
        {content}
      </section>
    </div>
  )
}

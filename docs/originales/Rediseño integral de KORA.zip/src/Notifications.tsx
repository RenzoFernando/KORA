import { useEffect, useRef, useState } from "react"
import { Icon } from "./Icon"

const notificationItems = [
  {
    id: "launch",
    artist: 0,
    cover: "cover-valentina-cruz.svg",
    title: "Nueva cápsula en San Antonio",
    body: "Valentina Cruz tiene una actualización de lanzamiento.",
    icon: "music",
  },
  {
    id: "comment",
    artist: 4,
    cover: "cover-maracuyas.svg",
    title: "Comentaron un hallazgo",
    body: "Un aporte agregó contexto de barrio a una cápsula compartida.",
    icon: "comment",
  },
  {
    id: "curator",
    artist: 0,
    cover: "cover-valentina-cruz.svg",
    title: "Una canción fue destacada",
    body: "La recomendación aparece como señal curatorial.",
    icon: "sparkles",
  },
]
export default function Notifications({ onOpen }: { onOpen: (index: number) => void }) {
  const [open, setOpen] = useState(false)
  const [unreadOnly, setUnreadOnly] = useState(false)
  const [read, setRead] = useState<string[]>(() => {
    try {
      const value = JSON.parse(
        localStorage.getItem("kora-notifications-read") || "[]",
      )
      return Array.isArray(value) ? value : []
    } catch {
      return []
    }
  })
  const container = useRef<HTMLDivElement>(null)
  const trigger = useRef<HTMLButtonElement>(null)
  const unread = notificationItems.filter((n) => !read.includes(n.id))
  const visible = unreadOnly ? unread : notificationItems
  useEffect(() => {
    try {
      localStorage.setItem("kora-notifications-read", JSON.stringify(read))
    } catch {}
  }, [read])
  useEffect(() => {
    if (!open) return
    const outside = (e: PointerEvent) => {
      if (!container.current?.contains(e.target as Node)) setOpen(false)
    }
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false)
        trigger.current?.focus()
      }
    }
    document.addEventListener("pointerdown", outside)
    document.addEventListener("keydown", key)
    return () => {
      document.removeEventListener("pointerdown", outside)
      document.removeEventListener("keydown", key)
    }
  }, [open])
  const mark = (id: string) =>
    setRead((items) => (items.includes(id) ? items : [...items, id]))
  return (
    <div className="notifications-anchor" ref={container}>
      <button
        ref={trigger}
        className="icon-btn notification-trigger"
        aria-label={`Notificaciones, ${unread.length} sin leer`}
        aria-expanded={open}
        aria-controls="notifications-panel"
        onClick={() => setOpen(!open)}
      >
        <Icon name="bell" />
        {unread.length > 0 && <b>{unread.length}</b>}
      </button>
      {open && (
        <section
          className="notifications-panel"
          id="notifications-panel"
          aria-label="Notificaciones"
        >
          <div className="notifications-heading">
            <div>
              <h2>Notificaciones</h2>
              <p>Actividad del catálogo KORΛ</p>
            </div>
            <button
              className="icon-btn"
              aria-label="Cerrar notificaciones"
              onClick={() => {
                setOpen(false)
                trigger.current?.focus()
              }}
            >
              <Icon name="close" />
            </button>
          </div>
          <div className="notifications-filters">
            <button
              aria-pressed={!unreadOnly}
              onClick={() => setUnreadOnly(false)}
            >
              Todas
            </button>
            <button
              aria-pressed={unreadOnly}
              onClick={() => setUnreadOnly(true)}
            >
              Sin leer {unread.length > 0 && `(${unread.length})`}
            </button>
          </div>
          <button
            className="mark-all"
            disabled={!unread.length}
            onClick={() => setRead(notificationItems.map((n) => n.id))}
          >
            <Icon name="check" />
            Marcar todas como leídas
          </button>
          <div className="notifications-feed">
            {visible.length ? (
              visible.map((n) => (
                <article
                  key={n.id}
                  className={read.includes(n.id) ? "read" : "unread"}
                >
                  <button
                    className="notification-open"
                    onClick={() => {
                      mark(n.id)
                      onOpen(n.artist)
                      setOpen(false)
                    }}
                  >
                    <img src={`/kora/img/${n.cover}`} alt="" />
                    <span>
                      <strong>{n.title}</strong>
                      <span>{n.body}</span>
                      <small>
                        Fecha no disponible ·{" "}
                        {read.includes(n.id) ? "Leída" : "Sin leer"}
                      </small>
                    </span>
                  </button>
                  <button
                    className="notification-read"
                    aria-label={`Marcar ${
                      read.includes(n.id) ? "como no leída" : "como leída"
                    }: ${n.title}`}
                    onClick={() =>
                      read.includes(n.id)
                        ? setRead((items) => items.filter((id) => id !== n.id))
                        : mark(n.id)
                    }
                  >
                    <Icon name={read.includes(n.id) ? "bell" : "check"} />
                  </button>
                </article>
              ))
            ) : (
              <div className="notifications-empty">
                <Icon name="bell" />
                <h3>Estás al día</h3>
                <p>No tienes notificaciones sin leer.</p>
              </div>
            )}
          </div>
          <p className="notifications-note">
            Avisos del catálogo de demostración. Estado guardado en este
            dispositivo.
          </p>
        </section>
      )}
    </div>
  )
}

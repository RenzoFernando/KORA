const paths: Record<string, string> = {
  home: "M3 10 12 3l9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1Z",
  play: "m9 5 11 7-11 7Z",
  pause: "M8 5v14M16 5v14",
  community:
    "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M16 4a4 4 0 0 1 0 8M22 21v-2a4 4 0 0 0-3-3.87M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0",
  plus: "M12 5v14M5 12h14",
  plans: "M3 7h18v13H3ZM3 11h18M7 16h3",
  user: "M20 21v-2a6 6 0 0 0-6-6h-4a6 6 0 0 0-6 6v2M16 6a4 4 0 1 1-8 0 4 4 0 0 1 8 0",
  bell: "M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4",
  settings:
    "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8M9 3l-1 3-3 1-2 3 2 2-1 4 3 2 3-1 2 4 3-1 1-3 4-1 1-3-2-2 1-4-3-2-3 1-2-3Z",
  sparkles: "m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5Z",
  heart:
    "M20.8 4.6a5.5 5.5 0 0 0-7.8 0l-1 1-1-1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z",
  share: "M12 16V3m-4 4 4-4 4 4M5 12v8h14v-8",
  chevron: "m9 5 7 7-7 7",
  down: "m6 9 6 6 6-6",
  previous: "m15 5-9 7 9 7M4 5v14",
  next: "m9 5 9 7-9 7M20 5v14",
  close: "m6 6 12 12M6 18 18 6",
  check: "m5 12 4 4L19 6",
  more: "M4 12h.01M12 12h.01M20 12h.01",
  music: "M9 18V5l12-3v14M9 8l12-3M9 18a3 3 0 1 1-3-3h3M21 16a3 3 0 1 1-3-3h3",
  comment: "M21 11a8 8 0 0 1-8 8H7l-5 3 2-6a8 8 0 1 1 17-5Z",
  expand: "M8 3H3v5M16 3h5v5M21 16v5h-5M8 21H3v-5",
  sidebar: "M3 4h18v16H3ZM9 4v16",
  sun: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1 1M18 18l1 1M5 19l1-1M18 6l1-1",
  moon: "M21 13a9 9 0 0 1-10-10A9 9 0 1 0 21 13Z",
  system: "M3 4h18v13H3ZM8 21h8M12 17v4",
}
export function Icon({ name }: { name: string }) {
  return (
    <svg
      className="symbol"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d={paths[name] || paths.music} />
    </svg>
  )
}

